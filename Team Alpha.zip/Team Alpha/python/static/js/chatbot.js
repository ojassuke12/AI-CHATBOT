//action after press
var input = document.getElementById("userInput");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
   event.preventDefault();
   mInput();
  }
});

//open close animation
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
//dynamic input field
document.body.addEventListener("focus", event => {
    const target = event.target;
    switch (target.tagName) {
        case "input":
        case "TEXTAREA":
        case "SELECT":
            document.body.classList.add("keyboard");
    }
}, true); 
document.body.addEventListener("blur", () => {
    document.body.classList.remove("keyboard");
}, true); 



// inserting text 
   function mInput() {
      var inputcheck=document.getElementById("userInput").value;
      if(!inputcheck.length == 0)
    {
      var d=new Date();
       var d1=document.createElement("div");
        d1.setAttribute("class","bubbleWrapper");
       var d2=document.createElement("div");
       d2.setAttribute("class","inlineContainer own");
       var d3=document.createElement("div");
       d3.setAttribute("class","ownBubble own");
       var spa=document.createElement("span");
       spa.setAttribute("class"," own");
    var input=document.getElementById("userInput").value;
    d3.innerHTML=input;
    spa.innerHTML=d.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })+"<c> YOU</c>";
    d2.appendChild(d3);
    d1.appendChild(d2);
    d1.appendChild(spa);
  var chat=document.getElementById("msgCont");
  chat.appendChild(d1);
var element = document.getElementById("msgCont");
   element.scrollTop = element.scrollHeight;

   document.getElementById("userInput").value="";
   
const msgText = input;
      if (!msgText) return;
     d3.innerHTML=msgText;
     botReply(msgText);
     
var element = document.getElementById("msgCont");
   element.scrollTop = element.scrollHeight;
    }
   }
   
   
   
   function botReply(rawText){
      var d=new Date();
      var d1=document.createElement("div");
        d1.setAttribute("class","bubbleWrapper");
       var d2=document.createElement("div");
       d2.setAttribute("class","inlineContainer ");
       var d3=document.createElement("div");
       d3.setAttribute("class","otherBubble other");
       var d4=document.createElement("div");
       d4.setAttribute("class","cssload-jumping");
       
 var d5=document.createElement("div");
       d5.setAttribute("class","msglogo");
       d1.appendChild(d5);
       var s1=document.createElement("span");
       var s2=document.createElement("span");
       var s3=document.createElement("span");
       var s4=document.createElement("span");
       var s5=document.createElement("span");
       var spa=document.createElement("span");
      d4.appendChild(s1);
      d4.appendChild(s2);
      d4.appendChild(s3);
      d4.appendChild(s4);
      d4.appendChild(s5);
      
       spa.setAttribute("class","other");
    spa.innerHTML="<h>GPN bot </h>"+d.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    
    d3.appendChild(d4);
    d2.appendChild(d3);
    d1.appendChild(d2);
    d1.appendChild(spa);
  var chat=document.getElementById("msgCont");
  chat.appendChild(d1);
  setTimeout(function(){}, 1500);
$.get("/get", { msg: rawText }).done(function (data) {
        const msgText = data;
        d3.removeChild(d3.childNodes[0]);
        d3.innerHTML=msgText;
      });
 
var element = document.getElementById("msgCont");
   element.scrollTop = element.scrollHeight;
 
   }
   
   
function c(){
var div = document.getElementById("msgCont"); 
            while(div.firstChild) { 
                div.removeChild(div.firstChild); 
            } 
        // hi again   
      var d=new Date();
      var d1=document.createElement("div");
        d1.setAttribute("class","bubbleWrapper");
       var d2=document.createElement("div");
       d2.setAttribute("class","inlineContainer ");
       var d3=document.createElement("div");
       d3.setAttribute("class","otherBubble other");
       var d4=document.createElement("div");
       d4.setAttribute("class","cssload-jumping");
       
 var d5=document.createElement("div");
       d5.setAttribute("class","msglogo");
       d1.appendChild(d5);
       var s1=document.createElement("span");
       var s2=document.createElement("span");
       var s3=document.createElement("span");
       var s4=document.createElement("span");
       var s5=document.createElement("span");
       var spa=document.createElement("span");
      d4.appendChild(s1);
      d4.appendChild(s2);
      d4.appendChild(s3);
      d4.appendChild(s4);
      d4.appendChild(s5);
      
       spa.setAttribute("class","other");
    spa.innerHTML="<h>GPN bot </h>"+d.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    
    d3.appendChild(d4);
    d2.appendChild(d3);
    d1.appendChild(d2);
    d1.appendChild(spa);
  var chat=document.getElementById("msgCont");
  chat.appendChild(d1);
     d3.removeChild(d3.childNodes[0]);
        d3.innerHTML="Hi! How can i help you?" ;
   }
